<template>
  <div>
    <div class="serve_show">
      <div class="show_wrap">
        <div class="show_title">
          <h1>产 品 展 示</h1>
        </div>
        <div class="show_img">
          <img src alt />
        </div>
      </div>
    </div>
    <div class="download">
      <div class="download_wrap">
        <h1>下 载 关 注</h1>
        <div class="download_box">
          <div class="download_wrap_left">
            <div class="download_wrap_left_img">
              <div class="download_wrap_left_img_img">
                <img src alt />
              </div>
              <p>有麦企服公众号</p>
            </div>
            <div class="download_wrap_left_img">
              <div class="download_wrap_left_img_img">
                <img src alt />
              </div>
              <p>有麦企服APP</p>
            </div>
          </div>
          <div class="download_wrap_right">
            <div class="download_wrap_right_img"></div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import '../../../styles/components/Product/Product_bottom/index.css'

export default {
    name:"serve_show",
    data(){
        return {
            
        }
    },
    components:{
        
    }
};
</script>

<style scoped>
</style>