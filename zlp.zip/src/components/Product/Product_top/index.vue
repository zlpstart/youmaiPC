<template>
  <div class="serve_li">
    <div class="li_box">
      <div class="box_img">
        <img src alt />
      </div>
      <div class="box_txt">
        <h1>智慧</h1>
        <p>简单简单简单简单简单简单简单简单</p>
      </div>
    </div>
    <div class="li_box">
      <div class="box_img">
        <img src alt />
      </div>
      <div class="box_txt">
        <h1>高效</h1>
        <p>简单简单简单简单简单简单简单简单</p>
      </div>
    </div>
    <div class="li_box">
      <div class="box_img">
        <img src alt />
      </div>
      <div class="box_txt">
        <h1>连接</h1>
        <p>简单简单简单简单简单简单简单简单</p>
      </div>
    </div>
  </div>
</template>

<script>
import '../../../styles/components/Product/Product_top/index.css'

export default {};
</script>

<style scoped>
</style>