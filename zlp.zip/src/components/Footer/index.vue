<template>
  <div>
    <div class="footerB">
      <div class="footer_wrap">
        <div class="footer_box">
          <h1>关于我们</h1>
          <p>有麦有麦有麦有麦有麦有麦有麦有麦有麦有麦有麦有麦有麦有麦有麦有麦有麦有麦有麦有麦有麦有麦有麦有麦有麦有麦有麦有麦有麦有麦有麦有麦有麦有麦有麦有麦有麦有麦有麦有麦</p>
        </div>
        <div class="footer_boxT">
          <h1>我们的产品</h1>
          <ul>
            <li>
              <router-link to>有麦企服</router-link>
            </li>
            <li>
              <router-link to>有麦家园</router-link>
            </li>
            <li>
              <router-link to>有麦集市</router-link>
            </li>
            <li>
              <router-link to>有麦MALL</router-link>
            </li>
            <li>
              <router-link to>有麦开发</router-link>
            </li>
            <li>
              <router-link to>有麦租房</router-link>
            </li>
          </ul>
        </div>
        <div class="footer_boxTT">
          <h1>有麦产业园</h1>
          <div class="footer_minbox">
            <div class="footer_img">
              <img src alt />
            </div>
            <div class="footer_p">
              <p>南京科创城</p>
              <p>南京雨花区大周路</p>
            </div>
          </div>
          <div class="footer_minbox">
            <div class="footer_img">
              <img src alt />
            </div>
            <div class="footer_p">
              <p>南京科创城</p>
              <p>南京雨花区大周路</p>
            </div>
          </div>
        </div>
        <div class="footer_contact">
          <h2>帮助与支持</h2>
          <h1>025-121453456</h1>
          <div class="footer_input">
            <input type="text" placeholder="Email" />
            <button>→</button>
          </div>
        </div>
      </div>
    </div>
    <div class="footer_wrapbox">
      <div class="footer_bottom">
        <p>Metropol 2016. All Rights Reserved.</p>
        <ul>
          <li>Blog</li>
          <li>|</li>
          <li>Privacy Policy</li>
          <li>|</li>
          <li>Terms of Use</li>
          <li>|</li>
          <li>Contacts</li>
        </ul>
      </div>
    </div>
  </div>
</template>

<script>
import '../../styles/components/Footer/index.css'

export default {
  name: "footerB",
  data() {
    return {};
  }
};
</script>

<style scoped>
</style>