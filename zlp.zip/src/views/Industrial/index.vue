<template>
  <div class="industrial">
    <div class="industrial_top">
      <navMenu />
    </div>
    <div class="industrial_content">
      <div class="content_box"></div>
      <div class="environment">
        <div class="environment_left"></div>
        <div class="environment_right">
          <h1>办公环境</h1>
          <p>办公环境办公环境办公环境办公环境办公环境办公环境办公环境办公环境办公环境办公环境办公环境办公环境办公环境办公环境办公环境办公环境办公环境办公环境办公环境办公环境办公环境办公环境办公环境办公环境办公环境办公环境办公环境办公环境办公环境办公环境办公环境办公环境办公环境办公环境办公环境办公环境办公环境办公环境办公环境办公环境办公环境办公环境办公环境办公环境办公环境办公环境办公环境办公环境办公环境办公环境办公环境办公环境办公环境办公环境办公环境办公环境办公环境办公环境办公环境办公环境办公环境办公环境办公环境办公环境办公环境办公环境办公环境办公环境办公环境办公环境办公环境办公环境办公环境办公环境办公环境办公环境办公环境办公环境办公环境办公环境办公环境办公环境办公环境办公环境办公环境</p>
        </div>
      </div>
      <div class="shoot">
        <div class="shoot_box">
          <div class="shoot_right">
            <div class="right_title">
              <h1>拍摄基地</h1>
            </div>
            <div class="right_txt">
              <p>拍摄场景拍摄场景拍摄场景拍摄场景拍摄场景拍摄场景拍摄场景拍摄场景拍摄场景拍摄场景拍摄场景拍摄场景拍摄场景拍摄场景拍摄场景拍摄场景拍摄场景拍摄场景拍摄场景拍摄场景拍摄场景拍摄场景拍摄场景拍摄场景拍摄场景拍摄场景拍摄场景拍摄场景拍摄场景拍摄场景拍摄场景拍摄场景拍摄场景拍摄场景拍摄场景拍摄场景拍摄场景拍摄场景拍摄场景拍摄场景拍摄场景拍摄场景拍摄场景拍摄场景</p>
            </div>
          </div>
        </div>
        <div class="shoot_box">
          <div class="shoot_left">
            <div class="right_title">
              <h1>拍摄基地</h1>
            </div>
            <div class="right_txt">
              <p>拍摄场景拍摄场景拍摄场景拍摄场景拍摄场景拍摄场景拍摄场景拍摄场景拍摄场景拍摄场景拍摄场景拍摄场景拍摄场景拍摄场景拍摄场景拍摄场景拍摄场景拍摄场景拍摄场景拍摄场景拍摄场景拍摄场景拍摄场景拍摄场景拍摄场景拍摄场景拍摄场景拍摄场景拍摄场景拍摄场景拍摄场景拍摄场景拍摄场景拍摄场景拍摄场景拍摄场景拍摄场景拍摄场景拍摄场景拍摄场景拍摄场景拍摄场景拍摄场景拍摄场景</p>
            </div>
          </div>
        </div>
      </div>
      <div class="leisure">
        <div class="leisure_box">
          <h1>休闲区</h1>
          <p>形象创意形象创意形象创意形象创意形象创意形象创意形象创意形象创意形象创意形象创意形象创意形象创意形象创意形象创意形象创意形象创意形象创意形象创意形象创意形象创意形象创意形象创意形象创意形象创意形象创意形象创意形象创意形象创意形象创意形象创意形象创意形象创意形象创意形象创意形象创意形象创意形象创意形象创意</p>
        </div>
        <div class="leisure_img">
          <img src alt />
        </div>
        <div class="leisure_img">
          <img src alt />
        </div>
        <div class="leisure_img">
          <img src alt />
        </div>
      </div>
    </div>
      <footerB/>
  </div>
</template>

<script>
import navMenu from "../../components/NavMenu/index";
import footerB from '../../components/Footer/index'
import "../../styles/view/Industrial/index.css";

export default {
  name: "industrial",
  data() {
    return {};
  },
  components: {
    navMenu,
    footerB
  }
};
</script>

<style scoped>
</style>