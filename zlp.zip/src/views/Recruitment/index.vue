<template>
  <div class="Recruitment">
    <div class="Recruitment_top">
      <navMenu />
    </div>
    <div class="Recruitment_content">
      <div class="Recruitment_introduce">
        <h1>公 司 介 绍</h1>
        <p>背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍</p>
      </div>
    </div>
    <div class="post">
      <div class="post_wrap">
        <h1>招 聘 职 位</h1>
        <div class="post_list">
          <div class="post_li">
            <ul>
              <li>UI设计师</li>
              <li>中国.南京</li>
              <li>技术部</li>
              <li>招聘2人</li>
              <li>→</li>
            </ul>
          </div>
          <div class="post_li">
            <ul>
              <li>UI设计师</li>
              <li>中国.南京</li>
              <li>技术部</li>
              <li>招聘2人</li>
              <li>→</li>
            </ul>
          </div>
          <div class="post_li">
            <ul>
              <li>UI设计师</li>
              <li>中国.南京</li>
              <li>技术部</li>
              <li>招聘2人</li>
              <li>→</li>
            </ul>
          </div>
          <div class="post_li">
            <ul>
              <li>UI设计师</li>
              <li>中国.南京</li>
              <li>技术部</li>
              <li>招聘2人</li>
              <li>→</li>
            </ul>
          </div>
          <div class="post_li">
            <ul>
              <li>UI设计师</li>
              <li>中国.南京</li>
              <li>技术部</li>
              <li>招聘2人</li>
              <li>→</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
    <div class="phone">
      <div class="phone_wrap">
        <h1>招 聘 专 线</h1>
        <div class="phone_list">
          <div class="phone_li">
            <div class="li_img">
              <img src alt />
            </div>
            <div class="li_txt">
              <p>邮 箱 地 址：</p>
              <h1>12345678@ym.com</h1>
            </div>
          </div>
          <div class="phone_li">
            <div class="li_img">
              <img src alt />
            </div>
            <div class="li_txt">
              <p>公 司 热 线：</p>
              <h1>025-123456789</h1>
            </div>
          </div>
          <div class="phone_li">
            <div class="li_img">
              <img src alt />
            </div>
            <div class="li_txt">
              <p>邮 箱 地 址：</p>
              <h1>12345678@ym.com</h1>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="Recruitment_bottom">
        <footerB/>
    </div>
  </div>
</template>

<script>
import navMenu from "../../components/NavMenu/index";
import footerB from "../../components/Footer/index";
import "../../styles/view/Recruitment/index.css";

export default {
  name: "Recruitment",
  data() {
    return {};
  },
  components: {
    navMenu,
    footerB
  }
};
</script>