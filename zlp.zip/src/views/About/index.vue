<template>
  <div class="about">
    <div class="about_top">
      <navMenu />
    </div>
    <div class="about_content">
      <div class="backdrop">
        <h1>背 景 介 绍</h1>
        <p>背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍背景介绍</p>
      </div>
    </div>
    <div class="about_list">
      <div class="about_wrap">
        <div class="list_box">
          <div class="box_img">
            <img src alt />
          </div>
          <div class="box_title">
            <h1>企业理念</h1>
          </div>
          <div class="box_list">
            <ul>
              <li>
                <span>服务 高效 简单</span>
              </li>
              <li>
                <span>服务 高效 简单</span>
              </li>
              <li>
                <span>服务 高效 简单</span>
              </li>
              <li>
                <span>服务 高效 简单</span>
              </li>
            </ul>
          </div>
        </div>
        <div class="list_box">
          <div class="box_img">
            <img src alt />
          </div>
          <div class="box_title">
            <h1>企业理念</h1>
          </div>
          <div class="box_list">
            <ul>
              <li>
                <span>服务 高效 简单</span>
              </li>
              <li>
                <span>服务 高效 简单</span>
              </li>
              <li>
                <span>服务 高效 简单</span>
              </li>
              <li>
                <span>服务 高效 简单</span>
              </li>
            </ul>
          </div>
        </div>
        <div class="list_box">
          <div class="box_img">
            <img src alt />
          </div>
          <div class="box_title">
            <h1>企业理念</h1>
          </div>
          <div class="box_list">
            <ul>
              <li>
                <span>服务 高效 简单</span>
              </li>
              <li>
                <span>服务 高效 简单</span>
              </li>
              <li>
                <span>服务 高效 简单</span>
              </li>
              <li>
                <span>服务 高效 简单</span>
              </li>
            </ul>
          </div>
        </div>
        <div class="list_box">
          <div class="box_img">
            <img src alt />
          </div>
          <div class="box_title">
            <h1>企业理念</h1>
          </div>
          <div class="box_list">
            <ul>
              <li>
                <span>服务 高效 简单</span>
              </li>
              <li>
                <span>服务 高效 简单</span>
              </li>
              <li>
                <span>服务 高效 简单</span>
              </li>
              <li>
                <span>服务 高效 简单</span>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
    <div class="advantage">
      <div class="advantage_wrap">
        <div class="advantage_title">
          <h1>我 们 的 优 势</h1>
        </div>
        <div class="advantage_list">
          <div class="advantage_box">
            <div class="advantage_box_img">
              <img src alt />
            </div>
            <div class="advantage_box_txt">
              <p>专业</p>
            </div>
          </div>
          <div class="advantage_box">
            <div class="advantage_box_img">
              <img src alt />
            </div>
            <div class="advantage_box_txt">
              <p>专业</p>
            </div>
          </div>
          <div class="advantage_box">
            <div class="advantage_box_img">
              <img src alt />
            </div>
            <div class="advantage_box_txt">
              <p>专业</p>
            </div>
          </div>
          <div class="advantage_box">
            <div class="advantage_box_img">
              <img src alt />
            </div>
            <div class="advantage_box_txt">
              <p>专业</p>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="about_bottom">
        <footerB />
    </div>
  </div>
</template>

<script>
import navMenu from "../../components/NavMenu/index";
import footerB from '../../components/Footer/index'
import "../../styles/view/About/index.css";

export default {
  name: "about",
  data() {
    return {};
  },
  components: {
    navMenu,
    footerB
  }
};
</script>

<style scoped>
</style>