<template>
  <div class="serve">
    <productTop/>
    <div class="serve_about">
      <div class="about_title">
        <h1>有 关 有 麦 企 服</h1>
      </div>
      <div class="about_content">
        <div class="content_left">
          <p>有麦企服是集有麦企服是集有麦企服是集有麦企服是集有麦企服是集有麦企服是集有麦企服是集有麦企服是集有麦企服是集有麦企服是集有麦企服是集有麦企服是集有麦企服是集有麦企服是集有麦企服是集</p>
          <p>有麦企服是集有麦企服是集有麦企服是集有麦企服是集有麦企服是集有麦企服是集有麦企服是集有麦企服是集有麦企服是集有麦企服是集有麦企服是集有麦企服是集有麦企服是集有麦企服是集有麦企服是集</p>
          <p>有麦企服是集有麦企服是集有麦企服是集有麦企服是集有麦企服是集有麦企服是集有麦企服是集有麦企服是集有麦企服是集有麦企服是集有麦企服是集有麦企服是集有麦企服是集有麦企服是集有麦企服是集</p>
        </div>
        <div class="content_right"></div>
      </div>
    </div>
    <div class="serve_details">
      <div class="details_wrap">
        <h1>有 麦 企 服 内 容</h1>
        <div class="details_maxbox">
          <div class="details_left">
            <img src alt />
          </div>
          <div class="details_right">
            <div class="right_boxs">
              <div class="boxs_img">
                <img src alt />
              </div>
              <div class="boxs_txt">
                <h1>投融资服务</h1>
                <p>为更好地帮助企业创业项目发展，为创业者搭建各种投融资渠道，积极引进投资机构，发挥创业项目与投资机构间的沟通桥梁作用</p>
              </div>
            </div>
            <div class="right_boxs">
              <div class="boxs_img">
                <img src alt />
              </div>
              <div class="boxs_txt">
                <h1>投融资服务</h1>
                <p>为更好地帮助企业创业项目发展，为创业者搭建各种投融资渠道，积极引进投资机构，发挥创业项目与投资机构间的沟通桥梁作用</p>
              </div>
            </div>
            <div class="right_boxs">
              <div class="boxs_img">
                <img src alt />
              </div>
              <div class="boxs_txt">
                <h1>投融资服务</h1>
                <p>为更好地帮助企业创业项目发展，为创业者搭建各种投融资渠道，积极引进投资机构，发挥创业项目与投资机构间的沟通桥梁作用</p>
              </div>
            </div>
            <div class="right_boxs">
              <div class="boxs_img">
                <img src alt />
              </div>
              <div class="boxs_txt">
                <h1>投融资服务</h1>
                <p>为更好地帮助企业创业项目发展，为创业者搭建各种投融资渠道，积极引进投资机构，发挥创业项目与投资机构间的沟通桥梁作用</p>
              </div>
            </div>
            <div class="right_boxs">
              <div class="boxs_img">
                <img src alt />
              </div>
              <div class="boxs_txt">
                <h1>投融资服务</h1>
                <p>为更好地帮助企业创业项目发展，为创业者搭建各种投融资渠道，积极引进投资机构，发挥创业项目与投资机构间的沟通桥梁作用</p>
              </div>
            </div>
            <div class="right_boxs">
              <div class="boxs_img">
                <img src alt />
              </div>
              <div class="boxs_txt">
                <h1>投融资服务</h1>
                <p>为更好地帮助企业创业项目发展，为创业者搭建各种投融资渠道，积极引进投资机构，发挥创业项目与投资机构间的沟通桥梁作用</p>
              </div>
            </div>
            <div class="right_boxs">
              <div class="boxs_img">
                <img src alt />
              </div>
              <div class="boxs_txt">
                <h1>投融资服务</h1>
                <p>为更好地帮助企业创业项目发展，为创业者搭建各种投融资渠道，积极引进投资机构，发挥创业项目与投资机构间的沟通桥梁作用</p>
              </div>
            </div>
            <div class="right_boxs">
              <div class="boxs_img">
                <img src alt />
              </div>
              <div class="boxs_txt">
                <h1>投融资服务</h1>
                <p>为更好地帮助企业创业项目发展，为创业者搭建各种投融资渠道，积极引进投资机构，发挥创业项目与投资机构间的沟通桥梁作用</p>
              </div>
            </div>
            <div class="right_boxs">
              <div class="boxs_img">
                <img src alt />
              </div>
              <div class="boxs_txt">
                <h1>投融资服务</h1>
                <p>为更好地帮助企业创业项目发展，为创业者搭建各种投融资渠道，积极引进投资机构，发挥创业项目与投资机构间的沟通桥梁作用</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <productBottom />
  </div>
</template>

<script>
import "../../../styles/view/Product/children/serve.css";
import productBottom from '../../../components/Product/Product_bottom/index.vue'
import productTop from '../../../components/Product/Product_top/index'

export default {
  name:"serve",
  data(){
    return {

    }
  },
  components:{
    productBottom,
    productTop
  }
};
</script>

<style scoped>
</style>