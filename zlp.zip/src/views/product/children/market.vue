<template>
  <div class="market">
    <productTop />
    <div class="market_about">
      <div class="market_about_wrap">
        <div class="market_about_wrap_title">
          <h1>关 于 有 麦 集 市</h1>
        </div>
        <div class="market_about_wrap_box">
          <div class="market_about_wrap_box_left">
            <img src alt />
          </div>
          <div class="market_about_wrap_box_right">
            <p>有麦企服是集有麦企服是集有麦企服是集有麦企服是集有麦企服是集有麦企服是集有麦企服是集有麦企服是集有麦企服是集有麦企服是集有麦企服是集有麦企服是集 有麦企服是集有麦企服是集有麦企服是集有麦企服是集有麦企服是集有麦企服是集有麦企服是集有麦企服是集有麦企服是集有麦企服是集有麦企服是集有麦企服是集有麦企服是集有麦企服是集有麦企服是集</p>
            <p>有麦企服是集有麦企服是集有麦企服是集有麦企服是集有麦企服是集有麦企服是集有麦企服是集有麦企服是集有麦企服是集有麦企服是集有麦企服是集有麦企服是集有麦企服是集有麦企服是集有麦企服是集 有麦企服是集有麦企服是集有麦企服是集有麦企服是集有麦企服是集有麦企服是集有麦企服是集有麦企服是集有麦企服是集有麦企服是集有麦企服是集有麦企服是集有麦企服是集有麦企服是集有麦企服是集 有麦企服是集有麦企服是集有麦企服是集有麦企服是集有麦企服是集有麦企服是集有麦企服是集有麦企服是集有麦企服是集有麦企服是集有麦企服是集有麦企服是集有麦企服是集有麦企服是集有麦企服是集 有麦企服是集有麦企服是集有麦企服是集有麦企服是集有麦企服是集有麦企服是集有麦企服是集有麦企服是集有麦企服是集有麦企服是集有麦企服是集有麦企服是集有麦企服是集有麦企服是集有麦企服是集</p>
            <p>有麦企服是集有麦企服是集有麦企服是集有麦企服是集有麦企服是集有麦企服是集有麦企服是集有麦企服是集有麦企服是集有麦企服是集有麦企服是集 有麦企服是集有麦企服是集有麦企服是集有麦企服是集有麦企服是集有麦企服是集有麦企服是集有麦企服是集有麦企服是集有麦企服是集有麦企服是集有麦企服是集有麦企服是集有麦企服是集有麦企服是集</p>
          </div>
        </div>
      </div>
    </div>
    <div class="market_show">
      <div class="market_show_wrap">
        <div class="market_show_wrap_box">
          <h1>有 麦 集 市</h1>
          <p>有麦租房自作主张自作主有麦租房有麦租房自作主张自作主有麦租房</p>
        </div>
      </div>
    </div>
    <div class="market_content">
        <div class="market_content_wrap">
            <div class="market_content_wrap_title">
                <h1>有 麦 集 市 内 容</h1>
            </div>
            <div class="market_content_wrap_img">
                <img src="" alt="">
            </div>
        </div>
    </div>
    <productBottom />
  </div>
</template>

<script>
import productTop from "../../../components/Product/Product_top/index";
import productBottom from "../../../components/Product/Product_bottom/index";
import "../../../styles/view/Product/children/market.css";

export default {
  name: "market",
  data() {
    return {};
  },
  components: {
    productTop,
    productBottom
  }
};
</script>

<style scoped>
</style>