<template>
  <div class="homeland">
    <productTop/>
    <div class="homeland_home">
      <div class="homeland_home_wrap">
        <div class="homeland_home_wrap_title">
          <h1>关 于 有 麦 家 园</h1>
        </div>
        <div class="homeland_home_wrap_content">
          <div class="homeland_home_wrap_content_box">
            <div class="homeland_home_wrap_content_box_img">
              <img src alt />
            </div>
            <div class="homeland_home_wrap_content_box_txt">
              <h1>有 麦 家 园</h1>
              <p>有麦家园有麦家园有麦家园有麦家园有麦家园有麦家园有麦家园有麦家园园有麦家园有麦家园有麦家园有麦家园有麦家园有麦家园有麦家园有麦家园有麦家园麦有麦家园有麦家园有麦家园有麦家园有麦家园有麦家园有麦家园有麦家园有麦家园有麦家园有麦家园有麦家园有麦家园有麦家园有麦家园有麦家园有麦家园有麦家园有麦家园麦</p>
              <p>有麦家园有麦家园有麦家园有麦家园有麦家园有麦家园有麦家园有麦家园有麦家园有麦家园有麦家园有麦家园有麦家园有麦家园有麦家园有麦家园麦有麦家园有麦家园有麦家园有麦家园有麦家园有麦家园有麦家园有麦家园有麦家园有麦家园有麦家园有麦家园有麦家园有麦家园有麦家园有麦家园有麦家园有麦家园有麦家园麦</p>
            </div>
          </div>
          <div class="homeland_home_wrap_content_box">
            <div class="homeland_home_wrap_content_box_txt">
              <h1>有 麦 家 园</h1>
              <p>有麦家园有麦家园有麦家园有麦家园有麦家园有麦家园有麦家园有麦家园园有麦家园有麦家园有麦家园有麦家园有麦家园有麦家园有麦家园有麦家园有麦家园麦有麦家园有麦家园有麦家园有麦家园有麦家园有麦家园有麦家园有麦家园有麦家园有麦家园有麦家园有麦家园有麦家园有麦家园有麦家园有麦家园有麦家园有麦家园有麦家园麦</p>
              <p>有麦家园有麦家园有麦家园有麦家园有麦家园有麦家园有麦家园有麦家园有麦家园有麦家园有麦家园有麦家园有麦家园有麦家园有麦家园有麦家园麦有麦家园有麦家园有麦家园有麦家园有麦家园有麦家园有麦家园有麦家园有麦家园有麦家园有麦家园有麦家园有麦家园有麦家园有麦家园有麦家园有麦家园有麦家园有麦家园麦</p>
            </div>
            <div class="homeland_home_wrap_content_box_img">
              <img src alt />
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="homeland_details">
      <div class="homeland_details_wrap">
        <div class="homeland_details_title">
          <h1>有 麦 家 园 内 容</h1>
        </div>
        <div class="homeland_details_img">
            <img src="" alt="">
        </div>
      </div>
    </div>
    <productBottom/>
  </div>
</template>

<script>
import "../../../styles/view/Product/children/homeland.css";
import productBottom from '../../../components/Product/Product_bottom/index'
import productTop from '../../../components/Product/Product_top/index'

export default {
    name:"",
    data(){
        return {

        }
    },
    components:{
        productBottom,
        productTop
    }
};
</script>

<style scoped>
</style>